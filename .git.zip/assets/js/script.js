// Add your custom scripts here
jQuery(document).ready(function($) {
    // Example script
    console.log('SmartMail Assistant scripts loaded.');

    // Add more interactivity as needed
    $('.smartmail-button').on('click', function() {
        alert('Button clicked!');
    });
});
